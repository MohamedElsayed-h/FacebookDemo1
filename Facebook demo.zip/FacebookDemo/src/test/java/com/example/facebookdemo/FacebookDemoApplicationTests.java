package com.example.facebookdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacebookDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
