# Document

#### I will explaint the project

* Github
* [a](https://sv-se.facebook.com/)


´´´

@GetMapping("/")
public String welcome(@ModelAttribute("user") User user,Model model){
model.addAttribute("users", userService.getAllUser());
return "user";
}

´´´

***Note that***





